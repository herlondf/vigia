# Vigia Mascot — Rig & Pose Pack

Pacote construído a partir do SVG original fornecido.

## Estrutura
- master/vigia-rig.svg — fonte única limpa.
- poses/ — 12 estados derivados do mesmo master.
- accessories/ — GitHub, Jira, lupa, warning e check.
- preview/poses.png — inspeção das 12 poses.
- preview/rig-parts.png — regras estruturais.

## Regra crítica
A barriga e seu sombreamento/borda permanecem na geometria original e não recebem transformações.
Isso elimina a regressão observada nas versões intermediárias.

## Estados
idle, monitoring, alert, success, investigating, sleeping, thinking, working,
error, warning, issue-found, resolved.

## Animação
O SVG-fonte possui algumas partes anatômicas fundidas em paths. Para movimentos extremos em Rive,
Lottie ou CSS/JS, mantenha este master como referência visual e complete a geometria oculta antes
de deslocar asas/pernas para longe da pose neutra.
